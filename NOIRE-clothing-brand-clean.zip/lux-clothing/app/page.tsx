'use client';

import { AnimatePresence, motion, useScroll, useTransform } from 'framer-motion';
import { useRef, useState } from 'react';

const products = [
  { name: 'Noir Structured Jacket', price: '$285', category: 'Tailoring', image: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=1200&q=78', reason: 'A sharp silhouette with enough restraint to move from first light to last call.' },
  { name: 'Pearl Silk Shirt', price: '$165', category: 'Shirting', image: 'https://images.unsplash.com/photo-1603252110481-7ba873bf42ab?auto=format&fit=crop&w=1000&q=78', reason: 'Soft light, clean lines and a finish that makes the simplest look feel considered.' },
  { name: 'Olive Tailored Trousers', price: '$195', category: 'Trousers', image: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&w=1000&q=78', reason: 'A refined everyday foundation, cut to keep its shape and quiet confidence.' },
  { name: 'Lilac Atelier Coat', price: '$390', category: 'Outerwear', image: 'https://images.unsplash.com/photo-1544022613-e87ca75a784a?auto=format&fit=crop&w=1200&q=78', reason: 'A statement layer in softened lilac—distinctive without asking for attention.' },
];

type Product = (typeof products)[number];

export default function Home() {
  const [selected, setSelected] = useState<Product | null>(null);
  const [bagCount, setBagCount] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const heroScale = useTransform(scrollYProgress, [0, 1], [1, 1.12]);
  const heroY = useTransform(scrollYProgress, [0, 1], [0, 80]);

  const openProduct = (product: Product) => setSelected(product);
  const addToBag = () => { setBagCount((count) => count + 1); setSelected(null); };

  return <main>
    <nav className="nav">
      <a className="wordmark" href="#top" aria-label="NOIRÉ home">NOIRÉ</a>
      <div className={`navlinks ${menuOpen ? 'mobileOpen' : ''}`}>
        <a href="#collection" onClick={() => setMenuOpen(false)}>Collection</a>
        <a href="#atelier" onClick={() => setMenuOpen(false)}>Atelier</a>
        <a href="#story" onClick={() => setMenuOpen(false)}>Story</a>
      </div>
      <div className="navActions">
        <button className="bag" onClick={() => document.getElementById('collection')?.scrollIntoView({ behavior: 'smooth' })}>Bag <span>{bagCount}</span></button>
        <button className="menuButton" aria-label="Toggle navigation" aria-expanded={menuOpen} onClick={() => setMenuOpen((v) => !v)}><span/><span/></button>
      </div>
    </nav>

    <section className="hero" id="top" ref={heroRef}>
      <motion.img style={{ scale: heroScale, y: heroY }} src="https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=2200&q=82" alt="Luxury fashion editorial" className="heroimg" priority="false" />
      <div className="heroShade" />
      <motion.div className="heroContent" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, ease: 'easeOut' }}>
        <p className="eyebrow">AUTUMN / WINTER 2026</p><h1>FORM.<br/>PRESENCE.<br/><i>DISTINCTION.</i></h1>
        <p className="heroCopy">Quietly expressive pieces designed for the moments that become memories.</p>
        <a className="cta" href="#collection">Explore collection <span>↗</span></a>
      </motion.div>
      <div className="scrollHint">SCROLL TO DISCOVER <span>↓</span></div>
    </section>

    <section className="intro" id="story"><p className="eyebrow olive">THE HOUSE OF NOIRÉ</p><h2>Not made to follow.<br/><em>Made to remain.</em></h2><p>NOIRÉ is an independent clothing atelier built around considered silhouettes, tactile materials and the confidence of knowing when less is enough.</p></section>

    <section className="collection" id="collection">
      <div className="sectionHead"><div><p className="eyebrow olive">01 / THE COLLECTION</p><h2>Pieces with <em>presence.</em></h2></div><p className="muted">Tap a piece to reveal its story.</p></div>
      <div className="grid" aria-label="NOIRÉ product gallery">
        {products.map((p, i) => <motion.button key={p.name} className={`card card${i} group`} whileHover={{ y: -8 }} whileTap={{ scale: .985 }} transition={{ type: 'spring', stiffness: 260, damping: 22 }} onClick={() => openProduct(p)} aria-label={`View ${p.name}`}>
          <img src={p.image} alt={p.name}/><div className="cardOverlay"><div><span>{p.category}</span><strong>{p.name}</strong></div><span className="plus transition-transform duration-300 group-hover:rotate-90">+</span></div>
        </motion.button>)}
      </div>
    </section>

    <section className="statement" id="atelier"><div className="statementImg"><img src="https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=1500&q=80" alt="NOIRÉ editorial"/></div><div className="statementText"><p className="eyebrow">02 / THE ATELIER</p><h2>Designed with<br/><em>intention.</em></h2><div className="principles"><div><b>01</b><span><strong>Material</strong> Selected for texture, weight and longevity.</span></div><div><b>02</b><span><strong>Form</strong> Clean silhouettes that let the wearer lead.</span></div><div><b>03</b><span><strong>Purpose</strong> Every detail earns its place.</span></div></div></div></section>

    <section className="signature"><div className="signatureCopy"><p className="eyebrow olive">03 / SIGNATURE PIECE</p><h2>The piece<br/>you'll <em>keep.</em></h2><p>The Noir Structured Jacket is cut with a deliberate shoulder, softened construction and a finish designed to become more personal with wear.</p><button className="outline" onClick={() => openProduct(products[0])}>Discover the jacket ↗</button></div><div className="signatureImg"><img src={products[0].image} alt="Noir Structured Jacket"/></div></section>

    <section className="final"><p className="eyebrow">NOIRÉ / 2026</p><h2>Your next piece<br/><em>starts here.</em></h2><a className="cta dark" href="#collection">Explore the collection <span>↗</span></a></section>
    <footer><div className="wordmark">NOIRÉ</div><div>© 2026 NOIRÉ Atelier</div><div>Instagram &nbsp; / &nbsp; Contact</div></footer>

    <AnimatePresence>{selected && <motion.div className="modalBack" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSelected(null)}>
      <motion.div className="productModal" initial={{ y: 60, scale: .96 }} animate={{ y: 0, scale: 1 }} exit={{ y: 60, scale: .96 }} transition={{ type: 'spring', damping: 24 }} onClick={e => e.stopPropagation()}>
        <button className="close" onClick={() => setSelected(null)} aria-label="Close product">×</button>
        <div className="modalImage"><img src={selected.image} alt={selected.name}/></div>
        <div className="modalInfo"><p className="eyebrow olive">{selected.category}</p><h2>{selected.name}</h2><div className="price">{selected.price}</div><p>{selected.reason}</p><button className="cta dark full" onClick={addToBag}>Add to bag <span>+</span></button><div className="details">Complimentary delivery · Easy returns · Crafted in limited quantities</div></div>
      </motion.div>
    </motion.div>}</AnimatePresence>
  </main>;
}
