import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'NOIRÉ — Form. Presence. Distinction.',
  description: 'NOIRÉ — an independent luxury clothing atelier built around considered silhouettes and tactile materials.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
